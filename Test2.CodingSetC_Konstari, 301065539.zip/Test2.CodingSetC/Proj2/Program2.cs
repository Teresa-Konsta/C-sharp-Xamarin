﻿using System;
using System.Linq;
using System.Collections.Generic;

/*
 * DO NOT add or delete the 'using' directives metioned above.
 * 
 * The Main method is already provided for you in this file 
 * for this project. DO NOT change this existing Main method.
 * 
 */ 


namespace Proj2
{
    class Program
    {
        private static T2 myMethod<T1, T2>(List<T1> l, Func<List<T1>, T2> del)
        {
            return del(l);
        }

        private static void doWork()
        {
            List<int> myList1 = new List<int>();
            myList1.Add(1); myList1.Add(2);
            myList1.Add(3); myList1.Add(4);

            //Call myMethod with the myList1 as the first argument
            //and a lambda expression as its second argument.
            //You must not use the 'return' keyword in the lambda expression.
            //You may use system-defined method(s) in the lambda expression.
            //The lambda expression should compute the sum of all
            //elements of myList1. The value returned by myMethod
            //should be stored in myResult1.
            //WRITE CODE BELOW.


            //var myResult1 = myMethod(myList1, myList1.Sum().ToString());
            var myResult1 = myList1.Sum().ToString();

            Console.WriteLine("myResult1 has: " + myResult1);


            List<string> myList2 = new List<string>();
            myList2.Add("A"); myList2.Add("AB");
            myList2.Add("ABC"); myList2.Add("ABCD");

            //Call myMethod with the myList2 as the first argument
            //and a lambda expression as its second argument. 
            //You must not use the 'return' keyword in the lambda expression.
            //You may use system-defined method(s) in the lambda expression.
            //The lambda expression should return the last element
            //of myList2. The value returned by myMethod
            //should be stored in myResult2
            //WRITE CODE BELOW.

            var myResult2 = myList2.Last();


            Console.WriteLine("myResult2 has: " + myResult2);

        }

        

        public static void Main(string[] args)
        {
            doWork();
            
            Console.ReadKey(); //halt execution
        }
    }
}

/*

The output from the above program should be as follows.

myResult1 has: 10
myResult2 has: ABCD

*/
