﻿using System;
using System.Collections.Generic;
using System.Linq;

/*
 * DO NOT add or delete the 'using' directives metioned above.
 * 
 * The Main method is already provided for you in this file 
 * for this project. DO NOT change this existing Main method.
 * 
 */


namespace Proj1
{
    //Define the methods mySelect and myWhere.
    //You may use a system-defined class in the body of these methods.
    //WRITE CODE BELOW.
    
    //Student: Tereza Konstari (301065539)




    public class Employee
    {
        public string Name { get; set; }
        public string Car { get; set; }
        public Employee(string name, string car)
        { Name = name; Car = car; }
    }

    public class Student
    {
        public string Name { get; set; }
        public string Course { get; set; }
        public Student(string name, string course)
        { Name = name; Course = course; }
    }


    public class Program
    {
        private static IEnumerable<Employee> employees = new List<Employee>() {
                            new Employee("Abha",    "Ford"),
                            new Employee("Krista",  "Honda")
        };

        private static IEnumerable<Student> students = new List<Student>() {
                            new Student("Mellisa",  "Math"),
                            new Student("Camila",   "Bio")
        };

        private static void projectAll()
        {
            Console.WriteLine("************");
            Console.WriteLine("projectAll: ");
            Console.WriteLine("************");

            //projects all attributes.
            var query1 = employees.Select((e) => e);
            foreach (var item in query1)
            {
                Console.WriteLine(item.Name + " " + item.Car);
            }

            var query2 = students.Select((e) => e);
            foreach (var item in query2)
            {
                Console.WriteLine(item.Name + " " + item.Course);
            }
        }        

        private static void projectName()
        {
            Console.WriteLine("*************");
            Console.WriteLine("projectName: ");
            Console.WriteLine("*************");

            //projects the attribute Name.
            var query1 = employees.Select( (e) => e.Name );
            foreach (var item in query1)
            {
                Console.WriteLine(item);
            }

            var query2 = students.Select((e) => e.Name);
            foreach (var item in query2)
            {
                Console.WriteLine(item);
            }
        }

        public static IEnumerable<Employee> mySelect(IEnumerable<Employee> employees)
        {
            IEnumerable<Employee> employeeList = new List<Employee>();

            foreach (var employee in employees)
            {
                employeeList.Append(employee);
            }
            return employeeList;
        }

        public static IEnumerable<Student> mySelect(IEnumerable<Student> students)
        {
            IEnumerable<Student> studentList = new List<Student>();

            foreach (var student in students)
            {
                studentList.Append(student);
            }
            return studentList;
        }

        private static void filter()
        {
            Console.WriteLine("********");
            Console.WriteLine("filter: ");
            Console.WriteLine("********");

            //filter on Car == "Honda"
            var query1 = employees.Where((e) => e.Car == "Honda") ;
            foreach (var item in query1)
            {
                Console.WriteLine(item.Name);
            }

            //filter on Course == "Bio"
            var query2 = students.Where((e) => e.Course == "Bio");
            foreach (var item in query2)
            {
                Console.WriteLine(item.Name);
            }
        }

        public static IEnumerable<Employee> myWhere(IEnumerable<Employee> employees)
        {
            IEnumerable<Employee> employeeList = new List<Employee>();

            foreach (var employee in employees)
            {
                employeeList.Append(employee);
            }
            return employeeList;
        }

        public static IEnumerable<Student> myWhere(IEnumerable<Student> students)
        {
            IEnumerable<Student> studentList = new List<Student>();

            foreach (var student in students)
            {
                studentList.Append(student);
            }
            return studentList;
        }

        public static void Main(string[] args)
        {
            projectAll();
            Console.WriteLine("");

            projectName();
            Console.WriteLine("");

            filter();
            Console.WriteLine("");

            Console.ReadKey(); //halt execution
        }       
    }
}

/*
 
The output from the above program should be as follows.

 
************
projectAll:
************
Abha Ford
Krista Honda
Mellisa Math
Camila Bio

*************
projectName:
*************
Abha
Krista
Mellisa
Camila

********
filter:
********
Krista
Camilla


*/
