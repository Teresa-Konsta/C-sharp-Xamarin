﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm_test1_Problem1
{
    public class Planet : INotifyPropertyChanged
    {
        public int PlanetID { get; set; }
        public string PlanetName { get; set; }
        public string PlanetColor { get; set; }

        event PropertyChangedEventHandler INotifyPropertyChanged.PropertyChanged
        {
            add
            {
                throw new NotImplementedException();
            }

            remove
            {
                throw new NotImplementedException();
            }
        }
    }
}
