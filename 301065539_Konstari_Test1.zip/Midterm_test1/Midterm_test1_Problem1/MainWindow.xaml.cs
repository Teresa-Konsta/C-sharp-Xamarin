﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Midterm_test1_Problem1
{
    //Tereza Konstari, 301065539
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static ObservableCollection<Fruit> FruitList = new ObservableCollection<Fruit>()
        {
            new Fruit(){FriutID = 1, FruitName = "Mango", FruitColor = "brown"},
            new Fruit(){FriutID = 2, FruitName = "Pitaya", FruitColor = "pink"},
            new Fruit(){FriutID = 3, FruitName = "Watermelon", FruitColor = "green"},
            new Fruit(){FriutID = 4, FruitName = "Pomegranate", FruitColor = "red"},
            new Fruit(){FriutID = 5, FruitName = "Orange", FruitColor = "orange"},
            new Fruit(){FriutID = 6, FruitName = "Melon", FruitColor = "yellow"},
            new Fruit(){FriutID = 7, FruitName = "Apple", FruitColor = "white"},
            new Fruit(){FriutID = 8, FruitName = "Blueberry", FruitColor = "blue"},
            new Fruit(){FriutID = 9, FruitName = "Mangosteen", FruitColor = "black"},
        };

        public static ObservableCollection<Planet> PlanetList = new ObservableCollection<Planet>()
        {
            new Planet() {PlanetID = 1, PlanetName = "Mercury", PlanetColor = "brown"},
            new Planet() {PlanetID = 2, PlanetName = "Venus", PlanetColor = "pink"},
            new Planet() {PlanetID = 3, PlanetName = "Earth", PlanetColor = "green"},
            new Planet() {PlanetID = 4, PlanetName = "Mars", PlanetColor = "red"},
            new Planet() {PlanetID = 5, PlanetName = "Jupiter", PlanetColor = "orange"},
            new Planet() {PlanetID = 6, PlanetName = "Saturn", PlanetColor = "yellow"},
            new Planet() {PlanetID = 7, PlanetName = "Uranus", PlanetColor = "white"},
            new Planet() {PlanetID = 8, PlanetName = "Neptune", PlanetColor = "blue"},
            new Planet() {PlanetID = 9, PlanetName = "Pluto", PlanetColor = "black"},
        };

        //public ObservableCollection<Fruit> selectedFruit = new ObservableCollection<Fruit>();
        //selectedFruit = GetObjectList();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            cmbFruit.SelectedItem = null;
            cmbPlanet.SelectedItem = null;
            Grid1.Columns.Clear();
            Grid2.Columns.Clear();
            Grid3.Columns.Clear();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            foreach (Fruit fruitSelected in FruitList)
            {
                if (cmbFruit.Text == fruitSelected.FruitName)
                {
                    //grid1ListView.SelectedItems.Remove(fruitSelected);
                }

            }

            foreach (Planet planetSelected in PlanetList)
            {
                if (cmbPlanet.Text == planetSelected.PlanetName)
                {
                    grid2ListView.SelectedItems.Remove(planetSelected);
                }
            }
        }

        private void cmbFruit_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            cmbPlanet.IsEnabled = false;
        }

        private void cmbFruit_DropDownClosed(object sender, EventArgs e)
        {
            foreach (Fruit fruit in FruitList)
            {
                if (cmbFruit.Text == fruit.FruitName)
                {
                    //grid1ListView.Items.Add($"{fruit.FriutID} {fruit.FruitName} {fruit.FruitColor}");
                }
            }
            //cmbPlanet.IsEnabled = false;
            //Grid2.Columns.Clear();
        }

        private void cmbFruit_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (Fruit fruit in FruitList)
            {
                cmbFruit.Items.Add(fruit.FruitName.ToString());
            }
        }
        private void cmbPlanet_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            cmbFruit.IsEnabled = false;
        }

        private void cmbPlanet_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (Planet planet in PlanetList)
            {
                cmbPlanet.Items.Add(planet.PlanetName.ToString());
            }
        }

        private void cmbPlanet_DropDownClosed(object sender, EventArgs e)
        {
            foreach (Planet planet in PlanetList)
            {
                if (cmbPlanet.Text == planet.PlanetName)
                {
                    grid2ListView.Items.Add($"{planet.PlanetID} {planet.PlanetName} {planet.PlanetColor}");
                }
            }
            //cmbFruit.IsEnabled = false;
            //Grid1.Columns.Clear();
        }

        private void Grid1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        { }

        private void Grid2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        { }

        private void Grid3_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //if(grid1ListView.SelectedItem == grid2ListView.Items)
            //{
            //    grid2ListView.Items.Add(grid1ListView.SelectedItem);
            //}
        }
    }
}
