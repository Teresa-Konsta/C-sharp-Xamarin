﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm_test1_Problem1
{
    public class Fruit : INotifyPropertyChanged
    {
        public int FriutID { get; set; }
        public string FruitName { get; set; }
        public string FruitColor { get; set; }

        event PropertyChangedEventHandler INotifyPropertyChanged.PropertyChanged
        {
            add
            {
                throw new NotImplementedException();
            }

            remove
            {
                throw new NotImplementedException();
            }
        }
    }
}
