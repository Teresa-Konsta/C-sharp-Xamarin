﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm_test1_Problem2
{
    public class Life : INotifyPropertyChanged
    {
            public string MyLife { get; set; }

        public Life() { MyLife = "HAPPY"; }

        event PropertyChangedEventHandler INotifyPropertyChanged.PropertyChanged
        {
            add
            {
                throw new NotImplementedException();
            }

            remove
            {
                throw new NotImplementedException();
            }
        }
    }
}
