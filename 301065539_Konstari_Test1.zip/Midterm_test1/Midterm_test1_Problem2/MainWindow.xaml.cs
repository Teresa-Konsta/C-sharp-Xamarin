﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Midterm_test1_Problem2
{
    //Tereza Konstari, 301065539
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        Life newLife = new Life();

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            txtResult1.Text = newLife.MyLife;
            txtResult2.Text = newLife.MyLife;
        }

        private void txtResult2_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtResult2.Text != null)
            {
                txtResult1.Text = txtResult2.Text;
            }
        }

        private void txtResult1_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
